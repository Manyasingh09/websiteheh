# Thornbound — companion website

A personal creative-showcase website for **Thornbound**, an otome villainess visual novel. Built as a static site (plain HTML/CSS/JS, no build step) so it can be deployed directly on GitHub Pages.

## Structure

```
index.html        Homepage
quiz.html          Compatibility quiz (route / house / discipline)
demo.html          One-act visual novel scene mockup (placeholder — in progress)
houses.html        Great Houses archive + family tree + map (placeholder — in progress)
journal.html       Character journal, flip-through (placeholder — in progress)
codex.html         In-world lore codex (placeholder — in progress)

css/
  tokens.css       Design tokens — colors, type, shared primitives. Edit here to reskin the whole site.
  nav.css          Shared ledger-tab navigation, used on every page.
  home.css         Homepage-only layout.
  quiz.css         Quiz-only layout.

data/
  quiz-data.js     Quiz questions, answers, and results — edit freely without touching layout/logic.

js/
  nav.js           Mobile nav toggle, shared across pages.
  quiz.js          Quiz scoring logic.
```

## Customizing

Look for `✎ CUSTOMIZE` comments in the CSS — they mark decorative choices (not structural ones) that are safe to change or delete without breaking layout.

## Deploying on GitHub Pages

1. Push this folder's contents to the root of a GitHub repository (or to a `/docs` folder, or a `gh-pages` branch — your choice).
2. In the repo's **Settings → Pages**, set the source to whichever branch/folder you used.
3. GitHub will publish at `https://<username>.github.io/<repo-name>/`.

No build step, no dependencies to install — it's ready to serve as-is.
